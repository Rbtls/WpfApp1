using System.Reflection;

[assembly: AssemblyTitle("Glfw.Net.Tests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Glfw.Net.Tests")]
[assembly: AssemblyCopyright("Copyright © Thomas Hourdel 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("1.0.*")]
