using System.Reflection;

[assembly: AssemblyTitle("Glfw.Net")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Glfw.Net")]
[assembly: AssemblyCopyright("Copyright © Thomas Hourdel 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("1.0.*")]
